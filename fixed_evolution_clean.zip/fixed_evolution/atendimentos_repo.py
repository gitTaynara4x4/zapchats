from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from backend import models


def has_mensagem_atendimento_field() -> bool:
    return hasattr(models.Mensagem, "atendimento_id")


def _get_atendimento_model():
    return getattr(models, "Atendimento", None)


def get_or_open_atendimento_repo(
    db: Session,
    *,
    empresa_id: int,
    instancia_id: int,
    cliente_id: int,
    direcao: str,
    ts_dt,
    operador_id: int | None = None,
) -> Any | None:
    if not has_mensagem_atendimento_field():
        return None

    Atendimento = _get_atendimento_model()
    if Atendimento is None:
        return None

    q = db.query(Atendimento)
    if hasattr(Atendimento, "empresa_id"):
        q = q.filter(Atendimento.empresa_id == int(empresa_id))
    if hasattr(Atendimento, "cliente_id"):
        q = q.filter(Atendimento.cliente_id == int(cliente_id))
    if hasattr(Atendimento, "instancia_id"):
        q = q.filter(Atendimento.instancia_id == int(instancia_id))
    if hasattr(Atendimento, "status"):
        try:
            q = q.filter(Atendimento.status.in_(["aberto", "em_atendimento", "pendente"]))
        except Exception:
            pass

    atendimento = None
    try:
        if hasattr(Atendimento, "id"):
            atendimento = q.order_by(Atendimento.id.desc()).first()
        else:
            atendimento = q.first()
    except Exception:
        atendimento = None

    if atendimento is not None:
        return atendimento

    try:
        novo = Atendimento()
    except Exception:
        return None

    if hasattr(novo, "empresa_id"):
        novo.empresa_id = int(empresa_id)
    if hasattr(novo, "cliente_id"):
        novo.cliente_id = int(cliente_id)
    if hasattr(novo, "instancia_id"):
        novo.instancia_id = int(instancia_id)
    if hasattr(novo, "status"):
        novo.status = "aberto"
    if hasattr(novo, "tipo"):
        novo.tipo = direcao
    if hasattr(novo, "direcao"):
        novo.direcao = direcao
    if hasattr(novo, "operador_id") and operador_id is not None:
        novo.operador_id = int(operador_id)
    if hasattr(novo, "criado_em") and ts_dt is not None:
        novo.criado_em = ts_dt
    if hasattr(novo, "created_at") and ts_dt is not None:
        novo.created_at = ts_dt
    if hasattr(novo, "updated_at") and ts_dt is not None:
        novo.updated_at = ts_dt

    db.add(novo)
    db.flush()
    return novo


def get_atendimento_id_repo(
    db: Session,
    *,
    empresa_id: int,
    instancia_id: int,
    cliente_id: int,
    direcao: str,
    ts_dt,
    operador_id: int | None = None,
) -> int | None:
    atendimento = get_or_open_atendimento_repo(
        db,
        empresa_id=empresa_id,
        instancia_id=instancia_id,
        cliente_id=cliente_id,
        direcao=direcao,
        ts_dt=ts_dt,
        operador_id=operador_id,
    )
    if atendimento is None:
        return None

    att_id = getattr(atendimento, "id", None)
    return int(att_id) if att_id is not None else None


def attach_atendimento_to_message_if_supported(msg_model, atendimento_id: int | None):
    if not has_mensagem_atendimento_field():
        return msg_model
    if atendimento_id is None:
        return msg_model
    if hasattr(msg_model, "atendimento_id"):
        setattr(msg_model, "atendimento_id", int(atendimento_id))
    return msg_model


__all__ = [
    "has_mensagem_atendimento_field",
    "get_or_open_atendimento_repo",
    "get_atendimento_id_repo",
    "attach_atendimento_to_message_if_supported",
]
