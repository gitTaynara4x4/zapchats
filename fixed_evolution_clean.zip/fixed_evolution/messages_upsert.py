from __future__ import annotations

import asyncio

from backend.database import SessionLocal
from backend import models
from backend.websocket_manager import conexoes_ativas

from ..parsers.message_parser import parse_messages_payload
from ..repositories.atendimentos_repo import (
    get_atendimento_id_repo,
    has_mensagem_atendimento_field,
)
from ..repositories.clientes_repo import (
    get_cliente_by_id,
    get_cliente_id_by_phone,
    upsert_cliente_repo,
)
from ..repositories.grupos_repo import (
    get_or_create_grupo_by_remote,
    insert_group_message,
)
from ..repositories.instancias_repo import (
    get_instancia_by_name,
    get_me_number_by_instancia,
)
from ..repositories.lid_map_repo import set_lid_mapping
from ..utils.log_utils import LOG, _short, _log_ctx, _log_skip
from ..utils.phone_utils import formatar_telefone_br, remote_to_num
from ..utils.time_utils import _iso_utc, _server_ts_ms
from ..utils.cache_utils import invalidate_emp_cache
from ._state import chatbot_should_process_msg
from .shared import (
    EvoEvent,
    HANDLERS,
    handler,
    find_existing_mensagem_11_id,
    insert_mensagem_11_with_retry,
    run_triagem_pos_commit,
    save_group_media_with_db,
    save_media_pos_commit_11,
    is_nome_grupo_ruim,
    evo_get_group_subject,
    avatar_from_contact_like,
)


def _stamp_inst(obj, inst) -> None:
    if obj is None or inst is None:
        return
    if hasattr(obj, "instancia_id") and getattr(obj, "instancia_id", None) is None:
        setattr(obj, "instancia_id", getattr(inst, "id", None))
    if hasattr(obj, "instance_name") and not getattr(obj, "instance_name", None):
        setattr(obj, "instance_name", getattr(inst, "instance_name", None))


@handler(EvoEvent.MESSAGES_UPSERT)
async def on_messages_upsert(inst_id: str, data):
    with SessionLocal() as db:
        inst = get_instancia_by_name(db, instance_name=inst_id)
        if not inst:
            LOG(f"[UPsert] instância não encontrada: {inst_id}")
            return

        empresa_id = int(inst.empresa_id)
        me_number = get_me_number_by_instancia(inst)

        mensagens = parse_messages_payload(
            data,
            inst_name=inst_id,
            empresa_id=empresa_id,
            instancia_id=getattr(inst, "id", None),
            me_number=me_number,
        )

        _log_ctx(
            "[UPsert] batch",
            inst=inst_id,
            empresa_id=empresa_id,
            total=len(mensagens),
            type_data=type(data).__name__,
        )

        if not mensagens:
            LOG("[UPsert] nenhum item reconhecido em payload.")
            return

        novas = 0
        chatbot_replay_batch_seen: set[tuple[int, str]] = set()

        for idx, parsed in enumerate(mensagens, start=1):
            try:
                raw = parsed.get("raw") or {}
                if not isinstance(raw, dict):
                    _log_skip("raw não é dict", idx=idx)
                    continue

                msg_id = parsed.get("msg_id")
                remote_jid = parsed.get("remote_jid")
                if not remote_jid:
                    _log_skip("sem remoteJid", idx=idx, msg_id=msg_id)
                    continue

                if parsed.get("lid_original_jid") and parsed.get("remote_jid") and not parsed.get("needs_lid_mapping"):
                    try:
                        set_lid_mapping(
                            empresa_id=empresa_id,
                            instancia_id=inst.id,
                            lid_jid=parsed["lid_original_jid"],
                            real_jid=parsed["remote_jid"],
                        )
                    except Exception as e:
                        _log_ctx("[UPsert][lid-cache-fail]", idx=idx, msg_id=msg_id, err=str(e))

                from_me = bool(parsed.get("from_me"))
                direcao = parsed.get("direcao") or ("saida" if from_me else "entrada")
                push_name = parsed.get("push_name")
                ts_msg = parsed.get("timestamp_dt")
                conteudo = parsed.get("conteudo") or ""
                media_meta = parsed.get("media_meta")
                ack_value = int(parsed.get("ack") or 0)

                _log_ctx(
                    "[UPsert][in]",
                    idx=idx,
                    msg_id=msg_id,
                    remote_jid=remote_jid,
                    from_me=from_me,
                    status=parsed.get("status"),
                    ts=(_iso_utc(ts_msg) if ts_msg else None),
                    preview=_short(conteudo),
                )

                if parsed.get("is_group"):
                    if not msg_id:
                        _log_skip("grupo sem msg_id", idx=idx, remote_jid=remote_jid)
                        continue

                    grp_remote = str(remote_jid).strip()

                    try:
                        grp = get_or_create_grupo_by_remote(
                            db,
                            empresa_id=empresa_id,
                            remote_jid=grp_remote,
                            instancia_id=getattr(inst, "id", None),
                            inst_obj=inst,
                            nome_padrao="Grupo",
                        )
                    except Exception as e:
                        grp = None
                        LOG(f"[UPsert][grupo] falha criando/buscando grupo: {e}")

                    if grp is None:
                        _log_skip("grupo sem grp-row", idx=idx, msg_id=msg_id, remote_jid=grp_remote)
                        continue

                    try:
                        if is_nome_grupo_ruim(getattr(grp, "nome", None)):
                            subject = evo_get_group_subject(getattr(inst, "instance_name", inst_id), grp_remote)
                            if subject and (grp.nome or "") != subject:
                                grp.nome = subject
                    except Exception:
                        pass

                    participant = parsed.get("participant_jid") or None
                    avatar = avatar_from_contact_like(raw)
                    try:
                        if isinstance(avatar, str) and avatar.strip():
                            if getattr(grp, "avatar_url", None) != avatar.strip():
                                grp.avatar_url = avatar.strip()
                        _stamp_inst(grp, inst)
                    except Exception:
                        pass

                    cli_autor_id = None
                    autor_nome = push_name or participant or None

                    try:
                        tel_autor = remote_to_num(participant) if participant else None
                        if tel_autor and (not me_number or tel_autor != me_number):
                            cli_autor_id = (
                                db.query(models.Cliente.id)
                                .filter(
                                    models.Cliente.empresa_id == empresa_id,
                                    models.Cliente.telefone == tel_autor,
                                )
                                .scalar()
                            )

                            if not cli_autor_id:
                                cli_autor_id = upsert_cliente_repo(
                                    db,
                                    empresa_id=empresa_id,
                                    instancia_id=inst.id,
                                    telefone_raw=tel_autor,
                                    nome=(push_name or formatar_telefone_br(tel_autor)),
                                    nome_whatsapp=(push_name or formatar_telefone_br(tel_autor)),
                                    avatar_url=None,
                                )
                    except Exception as e:
                        _log_ctx("[UPsert][grupo][autor-upsert-fail]", idx=idx, msg_id=msg_id, err=str(e))

                    inserted = False
                    gm_id = None

                    try:
                        gm_id, inserted = insert_group_message(
                            db,
                            empresa_id=empresa_id,
                            grupo_id=grp.id,
                            instancia_id=getattr(inst, "id", None),
                            author_jid=participant,
                            from_me=from_me,
                            conteudo=conteudo,
                            tipo=direcao,
                            message_type=parsed.get("message_type"),
                            lida=bool(from_me),
                            timestamp_dt=ts_msg,
                            msg_id=str(msg_id),
                            ack=int(ack_value or 0),
                            inst_obj=inst,
                        )

                        if inserted and gm_id:
                            novas += 1
                        else:
                            _log_skip("duplicada grupo (msg_id)", idx=idx, msg_id=msg_id, grupo_id=grp.id)

                    except Exception as e:
                        LOG(f"[UPsert][grupo][erro ao salvar] idx={idx} msg_id={msg_id} err={e}")
                        try:
                            db.rollback()
                        except Exception:
                            pass
                        continue

                    if media_meta and (inserted or gm_id):
                        try:
                            save_group_media_with_db(
                                db,
                                inst_id=inst_id,
                                empresa_id=empresa_id,
                                grupo_id=grp.id,
                                cliente_id=cli_autor_id,
                                msg_id=str(msg_id),
                                media_meta=media_meta,
                                instancia_db_id=inst.id,
                                idx=idx,
                            )
                        except Exception as e:
                            _log_ctx("[UPsert][grupo][midia] erro ao salvar", idx=idx, msg_id=msg_id, err=str(e))

                    if inserted:
                        try:
                            ws_payload_grupo = {
                                "empresa_id": empresa_id,
                                "cliente_id": grp.id,
                                "conversation_id": grp.id,
                                "grupo_id": grp.id,
                                "is_group": True,
                                "instancia_id": inst.id,
                                "instance_name": getattr(inst, "instance_name", None),
                                "telefone": getattr(grp, "remote_jid", grp_remote),
                                "avatar_url": getattr(grp, "avatar_url", None),
                                "push_name": getattr(grp, "nome", None),
                                "nome": getattr(grp, "nome", None) or "Grupo",
                                "mensagem": conteudo,
                                "tipo": direcao,
                                "origem": ("atendente" if from_me else "cliente"),
                                "timestamp": _iso_utc(ts_msg),
                                "msg_id": str(msg_id),
                                "ack": (ack_value if from_me else None),
                                "author_jid": participant,
                                "autor_nome": autor_nome,
                                "autor_cliente_id": cli_autor_id,
                                "serverTimestamp": _server_ts_ms(),
                            }
                            await conexoes_ativas.send_message(f"emp:{empresa_id}", ws_payload_grupo)
                        except Exception as e:
                            LOG(f"[UPsert][grupo][ws-live] falha ao emitir: {e}")

                        try:
                            await conexoes_ativas.send_message(
                                f"emp:{empresa_id}",
                                {"type": "reload_grupos", "serverTimestamp": _server_ts_ms()},
                            )
                        except Exception as e:
                            LOG(f"[UPsert][grupo][ws] falha reload_grupos: {e}")

                    if (novas % 500) == 0:
                        await asyncio.sleep(0)

                    continue

                telefone = parsed.get("telefone")
                if not telefone:
                    _log_skip("telefone inválido", idx=idx, msg_id=msg_id, remote_jid=remote_jid)
                    continue

                if me_number and telefone == me_number:
                    _log_skip("eco do meu número", idx=idx, msg_id=msg_id, telefone=telefone)
                    continue

                formatted = formatar_telefone_br(telefone)

                try:
                    cli_id = get_cliente_id_by_phone(db, empresa_id=empresa_id, telefone=telefone)
                except Exception as e:
                    LOG(f"[UPsert][erro select_cliente] idx={idx} msg_id={msg_id} err={e}")
                    try:
                        db.rollback()
                    except Exception:
                        pass
                    continue

                if not cli_id:
                    try:
                        cli_id = upsert_cliente_repo(
                            db,
                            empresa_id=empresa_id,
                            instancia_id=inst.id,
                            telefone_raw=telefone,
                            nome=(formatted if from_me else (push_name or formatted)),
                            nome_whatsapp=(formatted if from_me else (push_name or formatted)),
                            avatar_url=None,
                        )
                    except Exception as e:
                        LOG(f"[UPsert][erro upsert_cliente] idx={idx} msg_id={msg_id} err={e}")
                        try:
                            db.rollback()
                        except Exception:
                            pass
                        continue

                if not cli_id:
                    _log_skip("cli_id vazio (select+upsert)", idx=idx, msg_id=msg_id, telefone=telefone)
                    continue

                replay_existing_msg_id = None

                if msg_id:
                    try:
                        msg_existente_id = find_existing_mensagem_11_id(
                            db,
                            empresa_id=empresa_id,
                            cliente_id=cli_id,
                            msg_id=str(msg_id),
                            instancia_id=inst.id,
                        )
                    except Exception as e:
                        LOG(f"[UPsert][erro precheck-msgid] idx={idx} msg_id={msg_id} err={e}")
                        try:
                            db.rollback()
                        except Exception:
                            pass
                        continue

                    if msg_existente_id:
                        replay_existing_msg_id = int(msg_existente_id)

                atendimento_id = None
                if has_mensagem_atendimento_field():
                    try:
                        atendimento_id = get_atendimento_id_repo(
                            db,
                            empresa_id=empresa_id,
                            instancia_id=inst.id,
                            cliente_id=cli_id,
                            direcao=direcao,
                            ts_dt=ts_msg,
                            operador_id=None,
                        )
                    except Exception:
                        try:
                            db.rollback()
                        except Exception:
                            pass
                        atendimento_id = None

                msg_db_id = None
                inserted_11 = False

                if msg_id:
                    if replay_existing_msg_id:
                        msg_db_id = int(replay_existing_msg_id)
                    else:
                        try:
                            msg_db_id, inserted_11 = await insert_mensagem_11_with_retry(
                                db,
                                empresa_id=empresa_id,
                                cliente_id=cli_id,
                                conteudo=conteudo,
                                tipo=direcao,
                                lida=bool(from_me),
                                ack=ack_value,
                                timestamp=ts_msg,
                                msg_id=str(msg_id),
                                instancia_id=inst.id,
                                atendimento_id=atendimento_id,
                                idx=idx,
                            )
                            if inserted_11 and msg_db_id:
                                try:
                                    db.commit()
                                except Exception:
                                    db.rollback()
                                    continue
                                novas += 1
                            else:
                                if msg_db_id:
                                    replay_existing_msg_id = int(msg_db_id)
                        except Exception as e:
                            LOG(f"[UPsert][erro upsert mensagem] idx={idx} msg_id={msg_id} err={e}")
                            try:
                                db.rollback()
                            except Exception:
                                pass
                            continue
                else:
                    try:
                        msg_model = models.Mensagem(
                            empresa_id=empresa_id,
                            cliente_id=cli_id,
                            conteudo=conteudo,
                            tipo=direcao,
                            lida=from_me,
                            ack=ack_value,
                            timestamp=ts_msg,
                            msg_id=None,
                            instancia_id=inst.id,
                        )
                        if atendimento_id is not None and hasattr(msg_model, "atendimento_id"):
                            setattr(msg_model, "atendimento_id", atendimento_id)

                        _stamp_inst(msg_model, inst)
                        db.add(msg_model)
                        db.flush()
                        msg_db_id = msg_model.id
                        db.commit()
                        novas += 1
                        inserted_11 = True
                    except Exception as e:
                        LOG(f"[UPsert][erro ao salvar mensagem sem msg_id] idx={idx} err={e}")
                        try:
                            db.rollback()
                        except Exception:
                            pass
                        continue

                should_run_chatbot = False
                if (not from_me) and direcao == "entrada" and conteudo:
                    if msg_id:
                        if chatbot_should_process_msg(empresa_id, inst.id, str(msg_id)):
                            if inserted_11 and msg_db_id:
                                should_run_chatbot = True
                            elif replay_existing_msg_id:
                                replay_key = (int(replay_existing_msg_id), str(msg_id))
                                if replay_key not in chatbot_replay_batch_seen:
                                    chatbot_replay_batch_seen.add(replay_key)
                                    msg_db_id = int(replay_existing_msg_id)
                                    should_run_chatbot = True
                    else:
                        if inserted_11 and msg_db_id:
                            should_run_chatbot = True

                if should_run_chatbot:
                    await run_triagem_pos_commit(
                        empresa_id=empresa_id,
                        instancia_id=inst.id,
                        telefone=telefone,
                        conteudo=conteudo,
                        direcao=direcao,
                        remote_jid=remote_jid,
                    )

                if inserted_11 and msg_db_id:
                    if media_meta:
                        await save_media_pos_commit_11(
                            inst_id=inst_id,
                            empresa_id=empresa_id,
                            cli_id=cli_id,
                            msg_db_id=msg_db_id,
                            msg_id=(str(msg_id) if msg_id else None),
                            media_meta=media_meta,
                            instancia_db_id=inst.id,
                            idx=idx,
                        )

                    try:
                        with SessionLocal() as db_ws:
                            cliente = get_cliente_by_id(db_ws, cli_id)

                        ws_payload = {
                            "empresa_id": empresa_id,
                            "cliente_id": cli_id,
                            "instancia_id": inst.id,
                            "instance_name": getattr(inst, "instance_name", None),
                            "atendimento_id": atendimento_id,
                            "telefone": formatar_telefone_br(telefone),
                            "avatar_url": getattr(cliente, "avatar_url", None) if cliente else None,
                            "push_name": getattr(cliente, "nome_whatsapp", None) if cliente else None,
                            "nome": getattr(cliente, "nome", None) if cliente else formatted,
                            "mensagem": conteudo,
                            "tipo": direcao,
                            "origem": ("atendente" if from_me else "cliente"),
                            "timestamp": _iso_utc(ts_msg),
                            "msg_id": str(msg_id) if msg_id else (str(msg_db_id) if msg_db_id else None),
                            "ack": (ack_value if from_me else None),
                            "serverTimestamp": _server_ts_ms(),
                        }

                        await conexoes_ativas.send_message(f"emp:{empresa_id}", ws_payload)
                    except Exception as e:
                        LOG(f"[UPsert][ws] falha ao emitir: {e}")

                    try:
                        invalidate_emp_cache(empresa_id)
                    except Exception:
                        pass

                if (novas % 500) == 0:
                    await asyncio.sleep(0)

            except Exception as e:
                LOG(f"[UPsert] erro em mensagem idx={idx}: {e}")
                try:
                    db.rollback()
                except Exception:
                    pass
                continue

        try:
            db.commit()
            _log_ctx("[UPsert][commit-final]", novas=novas)
        except Exception as e:
            try:
                db.rollback()
            except Exception:
                pass
            LOG(f"[UPsert][commit-final-erro] {e}")

        try:
            if novas > 0 and empresa_id:
                invalidate_emp_cache(empresa_id)
        except Exception:
            pass

        LOG(f"[UPsert] inst={inst_id} novas={novas}")


HANDLERS[EvoEvent.MESSAGES_UPSERT] = on_messages_upsert
