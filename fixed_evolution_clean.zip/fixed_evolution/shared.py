from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.database import SessionLocal

from ..repositories.grupos_repo import (
    get_or_create_grupo_by_remote,
    upsert_grupos_from_chats as repo_upsert_grupos_from_chats,
)
from ..repositories.mensagens_repo import (
    find_existing_mensagem_11_id as repo_find_existing_mensagem_11_id,
    insert_mensagem_11_on_conflict,
)
from ..services.chatbot_service import run_chatbot_for_inbound
from ..services.media_service import (
    save_media_for_group_message_with_db,
    save_media_for_message_11_with_db,
)
from ..transport.evolution_http_client import EvolutionHttpClient
from ..utils.log_utils import LOG, _log_ctx
from ..utils.time_utils import _int_unix, _now_utc

HANDLERS: dict[str, Callable[..., Any]] = {}


class EvoEvent:
    APPLICATION_STARTUP = "APPLICATION_STARTUP"
    QRCODE_UPDATED = "QRCODE_UPDATED"
    CONNECTION_UPDATE = "CONNECTION_UPDATE"
    MESSAGES_SET = "MESSAGES_SET"
    MESSAGES_UPSERT = "MESSAGES_UPSERT"
    MESSAGES_UPDATE = "MESSAGES_UPDATE"
    MESSAGES_DELETE = "MESSAGES_DELETE"
    SEND_MESSAGE = "SEND_MESSAGE"
    CONTACTS_SET = "CONTACTS_SET"
    CONTACTS_UPSERT = "CONTACTS_UPSERT"
    CONTACTS_UPDATE = "CONTACTS_UPDATE"
    PRESENCE_UPDATE = "PRESENCE_UPDATE"
    GROUPS_UPSERT = "GROUPS_UPSERT"
    GROUPS_UPDATE = "GROUPS_UPDATE"
    GROUP_UPDATE = "GROUP_UPDATE"
    GROUP_PARTICIPANTS_UPDATE = "GROUP_PARTICIPANTS_UPDATE"
    NEW_TOKEN = "NEW_TOKEN"
    CALL = "CALL"
    LOGOUT_INSTANCE = "LOGOUT_INSTANCE"
    INSTANCE_DELETE = "INSTANCE_DELETE"
    REMOVE_INSTANCE = "REMOVE_INSTANCE"


def _normalize_event_names(names: tuple[Any, ...]) -> list[str]:
    out: list[str] = []
    for item in names:
        if isinstance(item, (list, tuple, set)):
            for sub in item:
                s = str(sub or "").strip()
                if s:
                    out.append(s.replace(".", "_").replace("-", "_").upper())
        else:
            s = str(item or "").strip()
            if s:
                out.append(s.replace(".", "_").replace("-", "_").upper())
    return out


def handler(*event_names: str):
    names = _normalize_event_names(event_names)

    def decorator(func: Callable[..., Any]):
        for name in names:
            existing = HANDLERS.get(name)
            if existing is None or existing is func:
                HANDLERS[name] = func
                continue

            async def _fanout(*args, _existing=existing, _func=func, **kwargs):
                results = []
                r1 = _existing(*args, **kwargs)
                if inspect.isawaitable(r1):
                    r1 = await r1
                results.append(r1)
                r2 = _func(*args, **kwargs)
                if inspect.isawaitable(r2):
                    r2 = await r2
                results.append(r2)
                return results

            HANDLERS[name] = _fanout

        return func

    return decorator


_GROUP_INFO_CACHE: dict[tuple[str, str], tuple[str, int]] = {}
_GROUP_INFO_TTL = 60 * 60


def is_nome_grupo_ruim(nome: str | None) -> bool:
    if not nome:
        return True
    n = str(nome).strip().lower()
    return (n == "") or (n in {"grupo", "group", "grupo do whatsapp", "whatsapp group"})


def evo_get_group_subject(instance_name: str, group_jid: str) -> str | None:
    if not instance_name or not group_jid:
        return None

    key = (instance_name, group_jid)
    now = _int_unix(_now_utc())
    cached = _GROUP_INFO_CACHE.get(key)
    if cached:
        subject_cached, ts_cached = cached
        if (now - ts_cached) < _GROUP_INFO_TTL:
            return subject_cached

    try:
        subject = EvolutionHttpClient().get_group_subject(instance_name, group_jid)
        if subject:
            _GROUP_INFO_CACHE[key] = (subject, now)
        return subject
    except Exception:
        return None


def is_statement_timeout_error(e: Exception) -> bool:
    base = getattr(e, "orig", e)
    msg = str(base).lower()
    return (
        "statement timeout" in msg
        or "canceling statement due to statement timeout" in msg
        or "querycanceled" in msg
        or "query canceled" in msg
        or "lock timeout" in msg
    )


def is_duplicate_key_error(e: Exception) -> bool:
    base = getattr(e, "orig", e)
    msg = str(base).lower()
    return (
        "duplicate key value violates unique constraint" in msg
        or "unique violation" in msg
        or "uq_mensagens_" in msg
    )


def find_existing_mensagem_11_id(
    db: Session,
    *,
    empresa_id: int,
    cliente_id: int | None,
    msg_id: str | None,
    instancia_id: int | None,
) -> int | None:
    return repo_find_existing_mensagem_11_id(
        db,
        empresa_id=empresa_id,
        cliente_id=cliente_id,
        msg_id=msg_id,
        instancia_id=instancia_id,
    )


async def insert_mensagem_11_with_retry(
    db: Session,
    *,
    empresa_id: int,
    cliente_id: int,
    conteudo: str,
    tipo: str,
    lida: bool,
    ack: int | None,
    timestamp,
    msg_id: str,
    instancia_id: int,
    atendimento_id: int | None,
    idx: int,
) -> tuple[int | None, bool]:
    for tentativa in range(3):
        try:
            return insert_mensagem_11_on_conflict(
                db,
                empresa_id=empresa_id,
                cliente_id=cliente_id,
                conteudo=conteudo,
                tipo=tipo,
                lida=lida,
                ack=ack,
                timestamp=timestamp,
                msg_id=msg_id,
                instancia_id=instancia_id,
                atendimento_id=atendimento_id,
            )
        except IntegrityError as e:
            try:
                db.rollback()
            except Exception:
                pass

            if is_duplicate_key_error(e):
                existente_id = repo_find_existing_mensagem_11_id(
                    db,
                    empresa_id=empresa_id,
                    cliente_id=cliente_id,
                    msg_id=msg_id,
                    instancia_id=instancia_id,
                )
                _log_ctx(
                    "[UPsert][duplicate-tolerated]",
                    idx=idx,
                    msg_id=msg_id,
                    cliente_id=cliente_id,
                    existing_id=existente_id,
                    err=str(e),
                )
                return existente_id, False

            if is_statement_timeout_error(e) and tentativa < 2:
                await asyncio.sleep(0.15 * (tentativa + 1))
                continue
            raise

        except Exception as e:
            try:
                db.rollback()
            except Exception:
                pass
            if is_statement_timeout_error(e) and tentativa < 2:
                await asyncio.sleep(0.15 * (tentativa + 1))
                continue
            raise


async def run_triagem_pos_commit(
    *,
    empresa_id: int,
    instancia_id: int,
    telefone: str,
    conteudo: str,
    direcao: str,
    remote_jid: str,
):
    return await run_chatbot_for_inbound(
        empresa_id=empresa_id,
        instancia_id=instancia_id,
        telefone=telefone,
        conteudo=conteudo,
        direcao=direcao,
        remote_jid=remote_jid,
    )


async def save_media_pos_commit_11(
    *,
    inst_id: str,
    empresa_id: int,
    cli_id: int,
    msg_db_id: int,
    msg_id: str | None,
    media_meta: dict,
    instancia_db_id: int,
    idx: int,
):
    with SessionLocal() as db_media:
        try:
            ok = save_media_for_message_11_with_db(
                db_media,
                inst_id=inst_id,
                empresa_id=empresa_id,
                cliente_id=cli_id,
                mensagem_id=msg_db_id,
                msg_id=msg_id,
                media_meta=media_meta,
                instancia_id=instancia_db_id,
                idx=idx,
            )
            if ok:
                db_media.commit()
            else:
                db_media.rollback()
        except Exception as e:
            try:
                db_media.rollback()
            except Exception:
                pass
            LOG(f"[UPsert][midia] erro ao salvar: {e}")


def save_group_media_with_db(
    db: Session,
    *,
    inst_id: str,
    empresa_id: int,
    grupo_id: int,
    cliente_id: int | None,
    msg_id: str | None,
    media_meta: dict,
    instancia_db_id: int,
    idx: int = 0,
) -> bool:
    return save_media_for_group_message_with_db(
        db,
        inst_id=inst_id,
        empresa_id=empresa_id,
        grupo_id=grupo_id,
        cliente_id=cliente_id,
        msg_id=msg_id,
        media_meta=media_meta,
        instancia_id=instancia_db_id,
        idx=idx,
    )


def grupo_row_by_remote(
    db: Session,
    empresa_id: int,
    remote_jid: str,
    instancia_id: int | None = None,
    inst_obj=None,
):
    return get_or_create_grupo_by_remote(
        db,
        empresa_id=empresa_id,
        remote_jid=remote_jid,
        instancia_id=instancia_id,
        inst_obj=inst_obj,
        nome_padrao="Grupo",
    )


def name_from_contact_like(c: dict) -> str | None:
    for k in (
        "verifiedName",
        "name",
        "pushName",
        "notifyName",
        "formattedName",
        "shortName",
        "contactName",
        "subject",
        "title",
        "displayName",
    ):
        v = c.get(k)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def avatar_from_contact_like(c: dict) -> str | None:
    return (
        c.get("profilePicUrl")
        or (c.get("profilePicThumbObj") or {}).get("eurl")
        or c.get("thumbnailUrl")
        or c.get("imageUrl")
        or c.get("pictureUrl")
        or None
    )


def upsert_grupos_from_chats(db: Session, empresa_id: int, chats: list[dict], inst) -> int:
    return repo_upsert_grupos_from_chats(
        db,
        empresa_id=empresa_id,
        chats=chats,
        inst=inst,
    )


__all__ = [
    "HANDLERS",
    "EvoEvent",
    "handler",
    "is_statement_timeout_error",
    "is_duplicate_key_error",
    "find_existing_mensagem_11_id",
    "insert_mensagem_11_with_retry",
    "run_triagem_pos_commit",
    "save_media_pos_commit_11",
    "save_group_media_with_db",
    "is_nome_grupo_ruim",
    "evo_get_group_subject",
    "grupo_row_by_remote",
    "name_from_contact_like",
    "avatar_from_contact_like",
    "upsert_grupos_from_chats",
]
