from __future__ import annotations

from .shared import EvoEvent, handler
from ..sync.history_sync import run_history_sync


@handler(EvoEvent.MESSAGES_SET)
async def on_messages_set(inst_id: str, data):
    return await run_history_sync(inst_id, data)


__all__ = [
    "on_messages_set",
]
