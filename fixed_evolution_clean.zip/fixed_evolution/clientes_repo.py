from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from backend import models


def get_cliente_by_id(db: Session, cliente_id: int | None) -> Optional[models.Cliente]:
    if not cliente_id:
        return None
    return db.query(models.Cliente).filter(models.Cliente.id == int(cliente_id)).first()


def get_cliente_id_by_phone(
    db: Session,
    *,
    empresa_id: int,
    telefone: str | None,
) -> int | None:
    raw = str(telefone or "").strip()
    if not raw:
        return None

    row = (
        db.query(models.Cliente.id)
        .filter(
            models.Cliente.empresa_id == int(empresa_id),
            models.Cliente.telefone == raw,
        )
        .scalar()
    )
    return int(row) if row else None


def get_cliente_by_phone(
    db: Session,
    *,
    empresa_id: int,
    telefone: str | None,
) -> Optional[models.Cliente]:
    raw = str(telefone or "").strip()
    if not raw:
        return None

    return (
        db.query(models.Cliente)
        .filter(
            models.Cliente.empresa_id == int(empresa_id),
            models.Cliente.telefone == raw,
        )
        .first()
    )


def upsert_cliente_repo(
    db: Session,
    *,
    empresa_id: int,
    instancia_id: int | None,
    telefone_raw: str,
    nome: str | None = None,
    nome_whatsapp: str | None = None,
    avatar_url: str | None = None,
) -> int | None:
    telefone = str(telefone_raw or "").strip()
    if not telefone:
        return None

    nome_final = str(nome or nome_whatsapp or telefone).strip()
    cli = get_cliente_by_phone(db, empresa_id=empresa_id, telefone=telefone)
    if not cli:
        cli = models.Cliente(
            empresa_id=int(empresa_id),
            telefone=telefone,
            nome=nome_final,
            nome_whatsapp=(str(nome_whatsapp or nome_final).strip() or None),
            avatar_url=avatar_url,
            instancia_id=(int(instancia_id) if instancia_id is not None else None),
        )
        db.add(cli)
        db.flush()
        return int(cli.id)

    changed = False
    if instancia_id is not None and getattr(cli, "instancia_id", None) is None:
        cli.instancia_id = int(instancia_id)
        changed = True

    if nome_whatsapp is not None:
        nome_wpp = str(nome_whatsapp).strip()
        if nome_wpp and getattr(cli, "nome_whatsapp", None) != nome_wpp:
            cli.nome_whatsapp = nome_wpp
            changed = True

    if nome_final and getattr(cli, "nome", None) != nome_final:
        cli.nome = nome_final
        changed = True

    if avatar_url is not None and getattr(cli, "avatar_url", None) != avatar_url:
        cli.avatar_url = avatar_url
        changed = True

    if changed:
        db.flush()

    return int(cli.id)


def update_cliente_metadata(
    db: Session,
    *,
    cliente_id: int,
    nome: str | None = None,
    nome_whatsapp: str | None = None,
    avatar_url: str | None = None,
    instancia_id: int | None = None,
) -> bool:
    cli = get_cliente_by_id(db, cliente_id)
    if not cli:
        return False

    changed = False
    if nome is not None and str(nome).strip() and getattr(cli, "nome", None) != str(nome).strip():
        cli.nome = str(nome).strip()
        changed = True

    if (
        nome_whatsapp is not None
        and str(nome_whatsapp).strip()
        and getattr(cli, "nome_whatsapp", None) != str(nome_whatsapp).strip()
    ):
        cli.nome_whatsapp = str(nome_whatsapp).strip()
        changed = True

    if avatar_url is not None and getattr(cli, "avatar_url", None) != avatar_url:
        cli.avatar_url = avatar_url
        changed = True

    if instancia_id is not None and getattr(cli, "instancia_id", None) is None:
        cli.instancia_id = int(instancia_id)
        changed = True

    return changed


def get_or_create_cliente_by_phone(
    db: Session,
    *,
    empresa_id: int,
    instancia_id: int | None,
    telefone: str,
    nome: str | None = None,
    nome_whatsapp: str | None = None,
    avatar_url: str | None = None,
) -> int | None:
    existente = get_cliente_id_by_phone(db, empresa_id=empresa_id, telefone=telefone)
    if existente:
        if nome is not None or nome_whatsapp is not None or avatar_url is not None or instancia_id is not None:
            update_cliente_metadata(
                db,
                cliente_id=existente,
                nome=nome,
                nome_whatsapp=nome_whatsapp,
                avatar_url=avatar_url,
                instancia_id=instancia_id,
            )
        return existente

    return upsert_cliente_repo(
        db,
        empresa_id=empresa_id,
        instancia_id=instancia_id,
        telefone_raw=telefone,
        nome=nome,
        nome_whatsapp=nome_whatsapp,
        avatar_url=avatar_url,
    )


__all__ = [
    "get_cliente_by_id",
    "get_cliente_id_by_phone",
    "get_cliente_by_phone",
    "upsert_cliente_repo",
    "update_cliente_metadata",
    "get_or_create_cliente_by_phone",
]
