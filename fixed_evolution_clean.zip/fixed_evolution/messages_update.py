from __future__ import annotations

from .shared import EvoEvent, handler
from ..services.ack_service import process_messages_update_ack


@handler(EvoEvent.MESSAGES_UPDATE)
async def on_messages_update(first: str, payload: dict | list):
    return await process_messages_update_ack(first, payload)


__all__ = [
    "on_messages_update",
]
